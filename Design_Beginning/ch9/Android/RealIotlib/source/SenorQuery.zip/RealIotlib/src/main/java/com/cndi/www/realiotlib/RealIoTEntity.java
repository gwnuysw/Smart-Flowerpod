package com.cndi.www.realiotlib;

/**
 * Created by dogu on 2016-04-26.
 */
public class RealIoTEntity {
    public int  entityId;
    public String entityUnit;
    public int  entityValue;
}
