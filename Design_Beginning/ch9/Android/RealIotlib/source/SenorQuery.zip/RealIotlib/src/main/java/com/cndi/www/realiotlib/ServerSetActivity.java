package com.cndi.www.realiotlib;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ServerSetActivity extends Activity {

	EditText etServerIp;
	EditText etloginID;
	EditText etLoginPass;

	public final static String SERVER_IP = "com.example.sensorquery.SERVER_IP";
	public final static String LOGINID = "com.example.sensorquery.LOGINID";
	public final static String LOGIN_PWD = "com.example.sensorquery.LOGINPWD";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_server_set);
		
		Intent ci = getIntent();
		String cServerIp = ci.getStringExtra(SERVER_IP);
		int  loginID = ci.getIntExtra(LOGINID, 1000);
		String strPwd = ci.getStringExtra(LOGIN_PWD);
	
		etServerIp = (EditText)findViewById(R.id.editTextServerIP);
		etServerIp.setText(cServerIp);
		
		etloginID = (EditText)findViewById(R.id.editTextPhoneID);
		etloginID.setText(Integer.toString(loginID));

		etLoginPass = (EditText)findViewById(R.id.editTextPassword);
		etLoginPass.setText(strPwd);
		
		Button btn = (Button)findViewById(R.id.buttonSetOk);
		btn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intentData = new Intent();
				intentData.putExtra(SERVER_IP, etServerIp.getText().toString());
				intentData.putExtra(LOGINID, Integer.parseInt(etloginID.getText().toString()));
				intentData.putExtra(LOGIN_PWD, etLoginPass.getText().toString() );
				setResult(RESULT_OK, intentData);
				finish();					
			}
		});
		
	}
		
}
