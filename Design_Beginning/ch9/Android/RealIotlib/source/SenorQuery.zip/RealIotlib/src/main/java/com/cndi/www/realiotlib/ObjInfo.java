package com.cndi.www.realiotlib;

/**
 * Created by dogu on 2016-04-27.
 */
public class ObjInfo {


    public int obj_type;
    public int obj_id;
    public String objDes;
}
