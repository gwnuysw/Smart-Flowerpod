package com.cndi.www.realiotlib;

/**
 * Created by dogu on 2016-04-27.
 */
public class PackObj {
    public final static int MAX_EXTRA_ID =  30;

    // detail cmd list
    public final static int CMD_DETAIL_NO_CMD   = 0;
    public final static int CMD_DETAIL_LOGIN_SUCCESS_RES = 1;
    public final static int CMD_DETAIL_LOGIN_FAIL_RES = 2;
    public final static int CMD_DETAIL_BASE_ID_RES = 3;
    public final static int CMD_DETAIL_CONT_ID_RES = 4 ;
    public final static int CMD_DETAIL_OBJ_ID_RES = 5 ;
    public final static int CMD_DETAIL_OBJ_ENT_RES = 6 ;

    public int cmdDetail;

    public int cmd;
    public int login_id;
    public int base_id;
    public int cont_id;
    public int object_id;
    public String strObj_des;
    public int obj_type;
    public int ent_num;

    public RealIoTEntity[] realEntityObj = new RealIoTEntity[Common.MAX_ENTITY_NUM];

    public ObjInfo[] extraObjInfo;
    public int[] extraArrayID;

}
