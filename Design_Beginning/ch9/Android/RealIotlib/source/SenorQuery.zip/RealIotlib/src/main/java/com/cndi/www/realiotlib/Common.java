package com.cndi.www.realiotlib;

/**
 * Created by dogu on 2016-04-27.
 */
public class Common {

    public final static int MAX_ENTITY_NUM = 2;
}
