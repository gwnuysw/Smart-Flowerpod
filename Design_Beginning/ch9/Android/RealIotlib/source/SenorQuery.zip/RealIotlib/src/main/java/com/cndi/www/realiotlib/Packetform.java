package com.cndi.www.realiotlib;

import android.util.Log;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;

/**
 * Created by dogu on 2016-04-27.
 */

/* packet form
STX     Len     Cmd     obj_id      cont_id     base_id     obj_des     id      pwd     obj_type    ent_num     ent_id1     ent_sort1   ent_val1    ent_id2     ent_sort2   ent_val2     ETX
2byte   4byte   1byte   4byte       4byte       4byte       20byte      4byte   10byte  1byte       1byte       1byte       4byte       4byte       1byte       4byte       4byte       1byte

STX  => 0xFD, 0xFE
ETX  => 0xFF
 */
public class Packetform {
    private static final String TAG = "Packetform";
    // cmd
    public final static int CMD_LOGIN_REQ = 0x30;
    public final static int CMD_LOGIN_RES = 0x31;

    public final static int CMD_OBJLIST_REQ = 0x20;
    public final static int CMD_OBJLIST_RES = 0x21;

    public final static int CMD_ACTUATOR_CONTROL_REQ = 0x11;



    public final static int STX_0  = 0xFD;
    public final static int STX_1  = 0xFE;

    public final static int ETX  = 0xFF;

    public final static int OBJ_TYPE_SENSOR = 0;
    public final static int OBJ_TYPE_ACTUATOR = 1;
    //final static int NORMAL_PACK_LEN  = 2+4+1+4+4+20+4+10+1+1+1+4+4+1+4+4+1;

    public final static int INDEX_STX = 0;
    public final static int INDEX_LEN =  INDEX_STX + 2;
    public final static int INDEX_CMD = INDEX_LEN +4;
    public final static int INDEX_OBJ_ID = INDEX_CMD + 1;
    public final static int INDEX_CONT_ID = INDEX_OBJ_ID + 4;
    public final static int INDEX_BASE_ID = INDEX_CONT_ID + 4;
    public final static int INDEX_OBJ_DES = INDEX_BASE_ID +4;
    public final static int INDEX_LOGINID = INDEX_OBJ_DES + 20;
    public final static int INDEX_LOGINPWD = INDEX_LOGINID + 4;
    public final static int INDEX_OBJ_TYPE = INDEX_LOGINPWD + 10;
    public final static int INDEX_ENT_NUM = INDEX_OBJ_TYPE + 1;
    public final static int INDEX_ENT_ID_1 = INDEX_ENT_NUM + 1;
    public final static int INDEX_ENT_SORT_1 = INDEX_ENT_ID_1 + 1;
    public final static int INDEX_ENT_VALUE_1 = INDEX_ENT_SORT_1+4;

    public final static int INDEX_ENT_ID_2 = INDEX_ENT_VALUE_1 + 4;
    public final static int INDEX_ENT_SORT_2 = INDEX_ENT_ID_2 + 1;
    public final static int INDEX_ENT_VALUE_2 = INDEX_ENT_SORT_2+4;
    public final static int INDEX_ETX = INDEX_ENT_VALUE_2 +4;

    public final static int NORMAL_PACK_LEN  = INDEX_ETX +1;


    private int nloginID;
    private String strLoginPassword;


    private byte ToUnSignedByte(int value) {
        int nTemp;
        if (value > 127) {
            nTemp = value - 256;
        } else
            nTemp = value;

        return (byte) nTemp;
    }

    private int unSignedByteToInt(byte value) {
        int nTemp;
        if (value >= 0)
            nTemp = (int) value;
        else
            nTemp = (int) value + 256;
        return nTemp;
    }

    private int byteArrayToInt(byte[] value, int offset)
    {
        int result;
        ByteBuffer wrapped = ByteBuffer.wrap(value, offset, 4);
        wrapped.order(ByteOrder.LITTLE_ENDIAN); // little endian {0x11,0x22,0x33,0x44} => 0x44332211
        result = wrapped.getInt(); // big endian {0x11,0x22,0x33,0x44} => 0x11223344
        return result;
    }
    private byte[] IntTobyteArray(int value)
    {
        ByteBuffer wrapped = ByteBuffer.allocate(4);
        wrapped.order(ByteOrder.LITTLE_ENDIAN);
        wrapped.putInt(value);
        byte[] arr = wrapped.array();
        return arr;
    }
    private String byteArrayToString(byte[] buff,int offset ,int maxLen )
    {
        byte[] temp = new byte[maxLen + 1];
        System.arraycopy(buff,offset,temp,0,maxLen);
        temp[maxLen] = 0;

        String strTemp = new String(temp);

        return strTemp;
    }

    // strPwd len MAX  10
    final static int MAX_PWD_LEN  = 10;
    public byte[] makeLoginPkt(int strid, String strPwd)
    {
        strLoginPassword = new String(strPwd);
        nloginID = strid;

//        Log.i(TAG,"Narmal packet lent:" +  NORMAL_PACK_LEN);
        byte[] pkt = new byte[NORMAL_PACK_LEN];

        int index =0;
        pkt[index++] = ToUnSignedByte(STX_0);
        pkt[index++] = ToUnSignedByte(STX_1);
        byte[] temp = IntTobyteArray(NORMAL_PACK_LEN - 7);
        pkt[index++] = temp[0];  // len
        pkt[index++] = temp[1];
        pkt[index++] = temp[2];
        pkt[index++] = temp[3];

        pkt[index++] = ToUnSignedByte(CMD_LOGIN_REQ); // cmd
        index += 4; // obj_id => 0
        index += 4;  //cont_id => 0
        index += 4;  // base_id => 0
        index += 20; // obj_des = 0
        temp = IntTobyteArray(strid);
        pkt[index++] = temp[0];  // login id
        pkt[index++] = temp[1];
        pkt[index++] = temp[2];
        pkt[index++] = temp[3];

        temp = strPwd.getBytes(Charset.forName("US-ASCII")); // login password
        if ( temp.length > MAX_PWD_LEN)
        {
            System.arraycopy(temp,0,pkt,index,MAX_PWD_LEN);
        }
        else
        {
            System.arraycopy(temp,0,pkt,index,temp.length);
        }

        // object type ~ entity_val2   => all zero
        pkt[NORMAL_PACK_LEN- 1] = ToUnSignedByte(ETX);

        return pkt;
    }

    public byte[] makeQueryPkt(int baseid, int controlid, int objid, int loginid)
    {
        byte[] pkt = new byte[NORMAL_PACK_LEN];
        int index =0;
        pkt[index++] = ToUnSignedByte(STX_0);
        pkt[index++] = ToUnSignedByte(STX_1);
        byte[] temp = IntTobyteArray(NORMAL_PACK_LEN-7);
        System.arraycopy(temp,0,pkt,index,4); // len
        index += 4;

        pkt[index++] = ToUnSignedByte(CMD_OBJLIST_REQ); // cmd
        temp = IntTobyteArray(objid);
        System.arraycopy(temp,0,pkt,index,4);
        index += 4; // obj_id => 0

        temp = IntTobyteArray(controlid);
        System.arraycopy(temp,0,pkt,index,4);
        index += 4;  //cont_id => 0

        temp = IntTobyteArray(baseid);
        System.arraycopy(temp,0,pkt,index,4);
        index += 4;  // base_id => 0

        index += 20; // obj_des = 0

        temp = IntTobyteArray(loginid);
        System.arraycopy(temp,0,pkt,index,4);
        index +=4; // login id

        // other region all => zero
        pkt[NORMAL_PACK_LEN- 1] = ToUnSignedByte(ETX);

        return pkt;
    }
    public byte[] makeActuatorControlPkt(int baseid, int controlid, int objid, int obj_type, int ent_num, int entityId1, int entityValue1, int entityId2, int entityValue2  )
    {
        byte[] pkt = new byte[NORMAL_PACK_LEN];
        int index =0;
        pkt[index++] = ToUnSignedByte(STX_0);
        pkt[index++] = ToUnSignedByte(STX_1);
        byte[] temp = IntTobyteArray(NORMAL_PACK_LEN-7);
        System.arraycopy(temp,0,pkt,index,4); // len
        index += 4;

        pkt[index++] = ToUnSignedByte(CMD_ACTUATOR_CONTROL_REQ); // cmd
        temp = IntTobyteArray(objid);
        System.arraycopy(temp,0,pkt,index,4);
        index += 4; // obj_id => 0

        temp = IntTobyteArray(controlid);
        System.arraycopy(temp,0,pkt,index,4);
        index += 4;  //cont_id => 0

        temp = IntTobyteArray(baseid);
        System.arraycopy(temp,0,pkt,index,4);
        index += 4;  // base_id => 0

        index += 20; // obj_des = 0

        temp = IntTobyteArray(nloginID);
        System.arraycopy(temp,0,pkt,index,4);
        index +=4; // login id

        index +=10; // login password

        pkt[index++] =  ToUnSignedByte(obj_type);
        pkt[index++] =  ToUnSignedByte(ent_num);

        if ( ent_num > 0) {
            pkt[index++] = ToUnSignedByte(entityId1);
            index += 4; // sort

            temp = IntTobyteArray(entityValue1);
            System.arraycopy(temp, 0, pkt, index, 4);
            index += 4;
        }

        if ( ent_num > 1) {

            pkt[index++] = ToUnSignedByte(entityId2);
            index += 4; // sort

            temp = IntTobyteArray(entityValue2);
            System.arraycopy(temp, 0, pkt, index, 4);
            index += 4;
        }
        // other region all => zero
        pkt[NORMAL_PACK_LEN- 1] = ToUnSignedByte(ETX);

        return pkt;
    }
    public boolean isValidPktForm(byte[] buff, int len)
    {
        if ( len < NORMAL_PACK_LEN) {
            Log.e(TAG,"isValidPktForm  is packet short:" +  len);
            return false;
        }

        if ( (buff[INDEX_STX] != ToUnSignedByte(STX_0) ) || (buff[INDEX_STX + 1] != ToUnSignedByte(STX_1))) {
            Log.e(TAG,"isValidPktForm  stx error:" );
            return false;
        }

        // lenth check
        int length = byteArrayToInt(buff,INDEX_LEN );
        if ((length + 7) != len )
        {
            Log.e(TAG,"isValidPktForm  length fail. rx len:" + len + ". length:" + length);
            return false;
        }

        // check etx
        if (buff[len-1] != ToUnSignedByte(ETX)) {
            Log.i(TAG,"isValidPktForm  ETX fail " );
            return false;
        }

        return true;
    }

    public PackObj getParcingPkt(byte[] buff, int len)
    {
        PackObj obj = new PackObj();
        obj.cmd = unSignedByteToInt(buff[INDEX_CMD]);
        obj.login_id = byteArrayToInt(buff, INDEX_LOGINID);
        obj.base_id = byteArrayToInt(buff, INDEX_BASE_ID);
        obj.cont_id = byteArrayToInt(buff, INDEX_CONT_ID);
        obj.object_id = byteArrayToInt(buff, INDEX_OBJ_ID);
        obj.strObj_des = byteArrayToString(buff, INDEX_OBJ_DES, 10);
        obj.obj_type = unSignedByteToInt(buff[INDEX_OBJ_TYPE]);
        obj.ent_num = unSignedByteToInt(buff[INDEX_ENT_NUM]);

        Log.i(TAG,"buff[INDEX_ENT_NUM]:" + buff[INDEX_ENT_NUM]);

        Log.i(TAG,"getParcingPkt   ent_num: " +  obj.ent_num + "INDEX_ENT_NUM:" + INDEX_ENT_NUM );

        if (obj.ent_num > Common.MAX_ENTITY_NUM )
            obj.ent_num = Common.MAX_ENTITY_NUM;

        obj.realEntityObj[0] = new RealIoTEntity();
        obj.realEntityObj[1] = new RealIoTEntity();
        if ( obj.ent_num > 0) {

            obj.realEntityObj[0].entityId = byteArrayToInt(buff, INDEX_ENT_ID_1);
            obj.realEntityObj[0].entityValue = byteArrayToInt(buff, INDEX_ENT_VALUE_1);
            obj.realEntityObj[0].entityUnit = byteArrayToString(buff, INDEX_ENT_SORT_1, 4);
        }

        if ( obj.ent_num > 1)
        {

            obj.realEntityObj[1].entityId = byteArrayToInt(buff, INDEX_ENT_ID_2);
            obj.realEntityObj[1].entityValue = byteArrayToInt(buff, INDEX_ENT_VALUE_2);
            obj.realEntityObj[1].entityUnit = byteArrayToString(buff, INDEX_ENT_SORT_2, 4);
        }

        if ( obj.cmd == CMD_LOGIN_RES)
        {
            if (obj.login_id !=  nloginID)
                obj.cmdDetail = PackObj.CMD_DETAIL_LOGIN_FAIL_RES;
            else
                obj.cmdDetail =  PackObj.CMD_DETAIL_LOGIN_SUCCESS_RES;

        }
        else if (obj.cmd == CMD_OBJLIST_RES )
        {
            if ( (obj.base_id == 0) && (obj.cont_id == 0) && (obj.object_id == 0 ) )
            {
                obj.cmdDetail = PackObj.CMD_DETAIL_BASE_ID_RES;
            }
            else if ( (obj.cont_id == 0) && (obj.object_id == 0 ) )
            {
                obj.cmdDetail = PackObj.CMD_DETAIL_CONT_ID_RES;
            }
            else if ( (obj.object_id == 0))
            {
                obj.cmdDetail = PackObj.CMD_DETAIL_OBJ_ID_RES;
            }
            else
                obj.cmdDetail  = PackObj.CMD_DETAIL_OBJ_ENT_RES;
        }
        else
        {
            obj.cmdDetail = PackObj.CMD_DETAIL_NO_CMD;
            return obj;
        }


        if (  obj.cmdDetail == PackObj.CMD_DETAIL_OBJ_ID_RES)
        {
            int extraInfoLen = (len - NORMAL_PACK_LEN ) / 25;
            int index = INDEX_ETX;
            obj.extraObjInfo = new ObjInfo[extraInfoLen];
            for (int i = 0; i < extraInfoLen ; i++) {
                obj.extraObjInfo[i] = new ObjInfo();
                obj.extraObjInfo[i].obj_type = unSignedByteToInt(buff[index]);
                index++;
                obj.extraObjInfo[i].obj_id = byteArrayToInt(buff, index);
                index += 4;
                obj.extraObjInfo[i].objDes = byteArrayToString(buff, index, 20);
                index += 20;
            }
        }
        else if ( (obj.cmdDetail == PackObj.CMD_DETAIL_CONT_ID_RES) || ( obj.cmdDetail == PackObj.CMD_DETAIL_BASE_ID_RES))
        {
            int extraInfoLen = (len - NORMAL_PACK_LEN ) / 4;
            obj.extraArrayID = new int[extraInfoLen];
            int index = INDEX_ETX;
            for (int i = 0; i < extraInfoLen ; i++ )
            {
                obj.extraArrayID[i] =  byteArrayToInt(buff, index);
                index +=4;
            }
        }

        // extra packet test
        return obj;
    }

}
