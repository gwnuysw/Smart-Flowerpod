package com.example.senorquery;

import static android.util.Log.d;

import java.net.InetAddress;
import java.util.Timer;
import java.util.TimerTask;

import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.cndi.www.realiotlib.*;


public class SensorQueryActivity extends Activity {

	private static final String TAG = "SensorQuery";
	final static int SERVER_SELECT = 2001;

	final static int SERVER_PORT = 50003;

	final static String PREF_FILE_NAME = "ServerInfo";
	final static String PREF_KEY_SERVERIP = "ServerIp";
	final static String PREF_KEY_LOGINID = "LOGINID";
	final static String PREF_KEY_LOGIN_PWD = "LoginPwd";

	final static int VIEW_ID_OFFSET = 1000;

	final static int UI_HANDLE_MSG_TABLE_CHANGE = 1;
	final static int UI_HANDLE_MSG_UPDATE = 2;
	final static int UI_HANDLE_MSG_ENTITY_CONTROL = 3;

	int loginID = 1000;
	String loginPwd = "1234567890";
	byte queryRobotID = 1; // Sensor query robot Id
	SharedPreferences prefs;

	String ServerIP;
	int ServerPort;

	Timer QuerySensorTimer;

	InetAddress ServerAddr;
	final static int MAX_PACKET_BUFF = 100;
	byte[] packet;
	/*  Table 표시 관련 */
	final static String TITLE_STR_BASE = "베이스 ID";
	final static String TITLE_STR_CONTROL = "/컨트롤 ID";
	final static String TITLE_STR_OBJECT = "/오브젝트 ID";
	final static String TITLE_STR_ENTITY = "/속성 값";


	NetManager NetMgr;

	Packetform packetform;
	TextView NetStatus;

	TextView title;

	final static int CUR_LEVEL_BASE_ID = 1;
	final static int CUR_LEVEL_CONTROL_ID = 2;
	final static int CUR_LEVEL_OBJECT_ID = 3;
	final static int CUR_LEVEL_VALUE = 4;

	private int curBaseId;
	private int curControlId;
	private int curObjId;
	private int[] curEntityIdArr = new int[Common.MAX_ENTITY_NUM];
	private int curEntityNum;
	private int curEntity_type;


	private int currentLevel; // 현재 표시 레벨
	private int curIndex = 0;
	PackObj packobj;

	private EditText[] etEntityValue = new EditText[Common.MAX_ENTITY_NUM];

	private boolean logined = false;

	ProgressBar progress;
	boolean connectingActionDoneFlag = false;

	TableLayout table;
	TableRow firstRow;
	private boolean tableRowColorToggle = false;


	private int testUpdateFlag = 0;
	private int testStep = 0;
	/**
	 * ATTENTION: This was auto-generated to implement the App Indexing API.
	 * See https://g.co/AppIndexing/AndroidStudio for more information.
	 */
//	private GoogleApiClient client;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_sensor_query);

		packetform = new Packetform();
		packobj = new PackObj();

		NetMgr = new NetManager();
		NetMgr.setRxHandler(mNetHandler);

		packet = new byte[MAX_PACKET_BUFF];

		// get server ip , port
		prefs = getSharedPreferences(PREF_FILE_NAME, MODE_PRIVATE);
		ServerIP = prefs.getString(PREF_KEY_SERVERIP, "192.168.10.38");
		loginID = prefs.getInt(PREF_KEY_LOGINID, 1000);
		loginPwd = prefs.getString(PREF_KEY_LOGIN_PWD, "1234567890");

//        disSeverSet(ServerIP,SERVER_PORT,loginID );
		Log.d(TAG, "ServerIP:" + ServerIP);
		Log.d(TAG, "ServerPort:" + SERVER_PORT);
		Log.d(TAG, "loginID:" + loginID);
		Log.d(TAG, "loginPwd:" + loginPwd);

		NetStatus = (TextView) findViewById(R.id.textViewNetState);

		progress = (ProgressBar) findViewById(R.id.progressBar);

		title = (TextView) findViewById(R.id.textViewCurStep);
		table = (TableLayout) findViewById(R.id.TableLayoutResult);

		firstRow = new TableRow(this);

		// add  table row
		TextView tvTemp = new TextView(this);
		tvTemp.setText("리스트");

		firstRow.addView(tvTemp);
		firstRow.setBackgroundColor(Color.YELLOW);

		curIndex = 1;
		table.addView(firstRow);

		changeLevel(CUR_LEVEL_BASE_ID, packobj);


		Button btn = (Button) findViewById(R.id.buttonServiceStart);
		btn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				btnEnable(false);

				NetMgr.setIpAndPort(ServerIP, SERVER_PORT);
				NetMgr.startThread();

				connectingActionDoneFlag = true;
				startQuerySensorTimer();
				showProgress(true);
			}
		});

		btn = (Button) findViewById(R.id.buttonServerSet);
		btn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				serverSel();

			}
		});

		btn = (Button) findViewById(R.id.btnBack);
		btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				navigateToback();
			}
		});

		btn = (Button) findViewById(R.id.buttonHome);
		btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				navigateTohome();
			}
		});
		btn = (Button) findViewById(R.id.buttonUpdate);
		btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				updateCurrentStep();
			}
		});

		showProgress(false);
		// ATTENTION: This was auto-generated to implement the App Indexing API.
		// See https://g.co/AppIndexing/AndroidStudio for more information.
//		client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
	}

	public void navigateToback() {
		Message msg = new Message();
		msg.what = UI_HANDLE_MSG_UPDATE;
		if (CUR_LEVEL_BASE_ID == currentLevel) {
			msg.arg1 = CUR_LEVEL_BASE_ID;
		} else if (CUR_LEVEL_CONTROL_ID == currentLevel) {
			msg.arg1 = CUR_LEVEL_BASE_ID;
		} else if (CUR_LEVEL_OBJECT_ID == currentLevel) {
			msg.arg1 = CUR_LEVEL_CONTROL_ID;
		} else if (CUR_LEVEL_VALUE == currentLevel) {
			msg.arg1 = CUR_LEVEL_OBJECT_ID;
		} else
			return;

		mTableUIHanlder.sendMessage(msg);
	}

	public void navigateTohome() {
		Message msg = new Message();
		msg.what = UI_HANDLE_MSG_UPDATE;
		msg.arg1 = CUR_LEVEL_BASE_ID;

		mTableUIHanlder.sendMessage(msg);

	}

	public void updateCurrentStep() {
		Message msg = new Message();
		msg.what = UI_HANDLE_MSG_UPDATE;
		msg.arg1 = currentLevel;

		mTableUIHanlder.sendMessage(msg);
	}

	public void showProgress(boolean show) {
		if (show) {
			progress.setVisibility(ProgressBar.VISIBLE);
			progress.setIndeterminate(true);
			progress.setMax(100);
		} else {
			progress.setVisibility(ProgressBar.GONE);
		}

	}

	public void changeLevel(int curStep, PackObj obj) {
		currentLevel = curStep;
		switch (curStep) {
			case CUR_LEVEL_BASE_ID:
				title.setText(TITLE_STR_BASE);
				break;
			case CUR_LEVEL_CONTROL_ID:
				title.setText(String.format("%08X", obj.base_id) + TITLE_STR_CONTROL);
				curBaseId = obj.base_id;
				break;
			case CUR_LEVEL_OBJECT_ID:
				title.setText(String.format("%08X/", obj.base_id) + String.format("%08X", obj.cont_id) + TITLE_STR_OBJECT);
				curBaseId = obj.base_id;
				curControlId = obj.cont_id;
				break;
			case CUR_LEVEL_VALUE:
				title.setText(String.format("%08X/", obj.base_id) + String.format("%08X/", obj.cont_id) + String.format("%08X", obj.object_id) + TITLE_STR_ENTITY);
				curBaseId = obj.base_id;
				curControlId = obj.cont_id;
				curObjId = obj.object_id;
				break;
		}
	}

	public void addTableRow(int value) {
		TableRow tempRow = new TableRow(this);

//		Button btnIndex = new Button(this);
//		btnIndex.setId(VIEW_ID_OFFSET +1);
//		btnIndex.setText("선택");

		// add  table row
		TextView tempTextView = new TextView(this);
		tempTextView.setText(String.format("%08X", value));
		if (tableRowColorToggle) {
			tempTextView.setBackgroundColor(Color.blue(40));
			tableRowColorToggle = false;
		} else {
			tempTextView.setBackgroundColor(Color.blue(20));
			tableRowColorToggle = true;
		}
		tempTextView.setTextColor(Color.RED);

		tempTextView.setId(curIndex++);

		tempTextView.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				onClickTextIndex(v);
			}
		});

		tempRow.addView(tempTextView);

		table.addView(tempRow);
	}

	public void addSimpleArrayTableRow(int[] arr) {
		for (int a : arr) {
			TableRow tempRow = new TableRow(this);
			// add  table row
			TextView tempTextView = new TextView(this);
			tempTextView.setText(String.format("%08X", a));

			tempTextView.setPadding(15, 3, 15, 3);
			if (tableRowColorToggle) {
				tempTextView.setBackgroundColor(Color.argb(0xff, 0xa2, 0xf4, 0xec));
				tableRowColorToggle = false;
			} else {
				tempTextView.setBackgroundColor(Color.argb(0xff, 0xa2, 0xf4, 0xff));
				tableRowColorToggle = true;
			}
			tempTextView.setTextColor(Color.RED);

			tempTextView.setId(a);

			tempTextView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					onClickTextIndex(v);
				}
			});

			tempRow.addView(tempTextView);

			table.addView(tempRow);
		}
	}

	public void displayBaseId(PackObj obj) {
		showProgress(false);
		clearTableRow();
		changeLevel(CUR_LEVEL_BASE_ID, obj);
		addSimpleArrayTableRow(obj.extraArrayID);
	}

	public void displayControlId(PackObj obj) {
		showProgress(false);
		clearTableRow();
		changeLevel(CUR_LEVEL_CONTROL_ID, obj);
		addSimpleArrayTableRow(obj.extraArrayID);
	}

	public void displayObjId(PackObj obj) {
		showProgress(false);
		clearTableRow();
		changeLevel(CUR_LEVEL_OBJECT_ID, obj);

		for (ObjInfo a : obj.extraObjInfo) {
			TableRow tempRow = new TableRow(this);
			// add  table row
			TextView tempTextView = new TextView(this);
			tempTextView.setText(String.format("%08X", a.obj_id));
			tempTextView.setId(a.obj_id);

			tempTextView.setPadding(15, 3, 15, 3);
			tempTextView.setBackgroundColor(Color.argb(0xff, 0xa2, 0xf4, 0xec));
			tempTextView.setTextColor(Color.RED);


			tempTextView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					onClickTextIndex(v);
				}
			});

			tempRow.addView(tempTextView);

			tempTextView = new TextView(this);
			tempTextView.setText(a.objDes);
			tempTextView.setPadding(15, 3, 15, 3);
			tempTextView.setBackgroundColor(Color.argb(0xff, 0xa2, 0xf4, 0xff));

			tempRow.addView(tempTextView);

			table.addView(tempRow);
		}
	}

	public void displayEntity(PackObj obj) {
		showProgress(false);
		clearTableRow();
		changeLevel(CUR_LEVEL_VALUE, obj);

		/*
		ID_1	XXXX		단위
		Value	XXXX		button  (if atuator)

		 */

		TextView tempTextView;
		Button tempBtn;
		curEntityNum = obj.ent_num;
		for (int i = 0; i < obj.ent_num; i++) {
			TableRow tempRow = new TableRow(this);
			// add  table row
			tempTextView = new TextView(this);
			tempTextView.setText("ID");
			tempTextView.setPadding(15, 3, 15, 3);
			tempTextView.setBackgroundColor(Color.argb(0xff, 0xa2, 0xf4, 0xec));
			tempRow.addView(tempTextView);

			tempTextView = new TextView(this);
			tempTextView.setText(String.format("%02X", obj.realEntityObj[i].entityId));
			tempTextView.setPadding(15, 3, 15, 3);
			tempTextView.setBackgroundColor(Color.argb(0xff, 0xa7, 0xf7, 0xf0));
			tempRow.addView(tempTextView);
			curEntityIdArr[i] = obj.realEntityObj[i].entityId;

			tempTextView.setPadding(15, 3, 15, 3);

			tempTextView = new TextView(this);
			tempTextView.setText(obj.realEntityObj[i].entityUnit + "(unit)");
			tempTextView.setPadding(15, 3, 15, 3);
			tempTextView.setBackgroundColor(Color.argb(0xff, 0xdf, 0xfc, 0xe6));
			tempRow.addView(tempTextView);

			table.addView(tempRow);

			tempRow = new TableRow(this);
			tempTextView = new TextView(this);
			tempTextView.setText("값");
			tempTextView.setPadding(15, 3, 15, 3);

			if (tableRowColorToggle) {
				tempTextView.setBackgroundColor(Color.argb(0xff, 0xa2, 0xf4, 0xec));
			} else {
				tempTextView.setBackgroundColor(Color.argb(0xff, 0xa2, 0xf4, 0xec));
			}
			tempRow.addView(tempTextView);


			if (obj.obj_type == Packetform.OBJ_TYPE_SENSOR) {
				tempTextView = new TextView(this);
				tempTextView.setText(Integer.toString(obj.realEntityObj[i].entityValue));
				tempTextView.setPadding(15, 3, 15, 3);
				tempTextView.setBackgroundColor(Color.argb(0xff, 0xa7, 0xf7, 0xf0));
				tempRow.addView(tempTextView);
			} else {
				etEntityValue[i] = new EditText(this);
				etEntityValue[i].setText(Integer.toString(obj.realEntityObj[i].entityValue));
				etEntityValue[i].setPadding(15, 3, 15, 3);
				etEntityValue[i].setBackgroundColor(Color.argb(0xff, 0xfc, 0xf2, 0xb8));
				tempRow.addView(etEntityValue[i]);

			}

			tempBtn = new Button(this, null, android.R.attr.buttonStyleSmall);

			tempBtn.setId(obj.realEntityObj[i].entityId);

			curEntity_type = obj.obj_type;
			if (obj.obj_type == Packetform.OBJ_TYPE_SENSOR) {
				tempBtn.setText("값 갱신");
			} else {
				tempBtn.setText("값 수정");
			}
			tempBtn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					onClickUpdateModifyButton(v);
				}
			});
			tempRow.addView(tempBtn);
			table.addView(tempRow);
		}
	}

	public void deleteTableRow(int index) {
		table.removeViews(index, 1);
	}

	public void clearTableRow() {
		table.removeViews(1, table.getChildCount() - 1);
	}

	public void onClickTextIndex(View v) {
		Log.i(TAG, "onClick: enter ");
		Log.i(TAG, "onClick:" + v.getId());
		Message msg = new Message();
		msg.what = UI_HANDLE_MSG_TABLE_CHANGE;
		msg.arg1 = currentLevel;
		msg.arg2 = v.getId();

		mTableUIHanlder.sendMessage(msg);
	}

	public void onClickUpdateModifyButton(View v) {
		Message msg = new Message();
		if (curEntity_type == Packetform.OBJ_TYPE_SENSOR) {
			msg.what = UI_HANDLE_MSG_UPDATE;
			msg.arg1 = currentLevel;
			msg.arg2 = curObjId;
		} else // actuator
		{
			msg.what = UI_HANDLE_MSG_ENTITY_CONTROL;
			if (curEntityNum > 0) {
				try {
					msg.arg1 = Integer.parseInt(etEntityValue[0].getText().toString());
				} catch (NumberFormatException e) {
					Log.e(TAG, "EntityValue 1 converion error.");
					Toast.makeText(this, "value 1 convertion to int  error.", Toast.LENGTH_LONG);
					return;
				}

			}
			if (curEntityNum > 1) {
				try {
					msg.arg2 = Integer.parseInt(etEntityValue[1].getText().toString());
				} catch (NumberFormatException e) {
					Log.e(TAG, "EntityValue 2 converion error.");
					Toast.makeText(this, "value 2 convertion to int  error.", Toast.LENGTH_LONG);
					return;
				}
			}

		}

		mTableUIHanlder.sendMessage(msg);
	}

	public void serverSel() {
		Intent intent = new Intent(this, ServerSetActivity.class);

		intent.putExtra(ServerSetActivity.SERVER_IP, ServerIP);
		intent.putExtra(ServerSetActivity.LOGINID, loginID);
		intent.putExtra(ServerSetActivity.LOGIN_PWD, loginPwd);
		startActivityForResult(intent, SERVER_SELECT);

	}

	private void startQuerySensorTimer() {
		QuerySensorTimer = new Timer();
		QuerySensorTimer.schedule(new TimerTask() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				//SendCmd(loginID, DEV_TYPE_SERVER, queryRobotID, CMD_SENSOR_REQ);
				//Log.d(TAG, "Send Alive");


			}

		}, 4000, 3000);
	}

	private void stopQuerySensorTimer() {
		QuerySensorTimer.cancel();
		QuerySensorTimer.purge();
	}

	private byte ToUnSignedByte(int value) {
		int nTemp;
		if (value > 127) {
			nTemp = value - 256;
		} else
			nTemp = value;

		return (byte) nTemp;
	}

	private int unSignedByteToInt(byte value) {
		int nTemp;
		if (value > 0)
			nTemp = (int) value;
		else
			nTemp = (int) value + 256;
		return nTemp;
	}


	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		if (requestCode == SERVER_SELECT) {
			if (resultCode == RESULT_OK) {
				ServerIP = data.getStringExtra(ServerSetActivity.SERVER_IP);

				Log.d(TAG, "setting Cloud Server IP:" + ServerIP);
				loginID = data.getIntExtra(ServerSetActivity.LOGINID, 1000);
				loginPwd = data.getStringExtra(ServerSetActivity.LOGIN_PWD);

//    			disSeverSet(ServerIP,SERVER_PORT,loginID);
				// save
				SharedPreferences.Editor ed = prefs.edit();
				ed.putString(PREF_KEY_SERVERIP, ServerIP);
				ed.putInt(PREF_KEY_LOGINID, loginID);
				ed.putString(PREF_KEY_LOGIN_PWD, loginPwd);

				ed.commit();

			}
		}

		super.onActivityResult(requestCode, resultCode, data);
	}

	/*
		private void disSeverSet(String ip , int port , int pID)
        {
            TextView tv = (TextView)findViewById(R.id.textViewServerIP);
            tv.setText("Server IP:" + ip +", PORT:" + Integer.toString(port) + ",PHONE ID:" + Integer.toString(pID));
        }
    */
	private Handler mNetHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);

			switch (msg.what) {
				case NetManager.HANDLE_RXCMD:
					doRxCmd(msg.getData());
					break;
				case NetManager.HANDLE_NETSTATUS:
					doNetStatus(msg.arg1);
					break;
			}
		}
	};


	private Handler mTableUIHanlder = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);

			switch (msg.what) {
				case UI_HANDLE_MSG_TABLE_CHANGE:
					clearTableRow();
					showProgress(true);
					if (msg.arg1 == CUR_LEVEL_BASE_ID) {
						SendControlIDQuery(msg.arg2);
					} else if (msg.arg1 == CUR_LEVEL_CONTROL_ID) {
						SendObjIdQuery(curBaseId, msg.arg2);
					} else if (msg.arg1 == CUR_LEVEL_OBJECT_ID) {
						SendEntQuery(curBaseId, curControlId, msg.arg2);
					}
					break;
				case UI_HANDLE_MSG_UPDATE:
					clearTableRow();
					showProgress(true);
					if (msg.arg1 == CUR_LEVEL_BASE_ID) {
						SendBaseIdQuery();
					} else if (msg.arg1 == CUR_LEVEL_CONTROL_ID) {
						SendControlIDQuery(curBaseId);
					} else if (msg.arg1 == CUR_LEVEL_OBJECT_ID) {
						SendObjIdQuery(curBaseId, curControlId);

					} else if (msg.arg1 == CUR_LEVEL_VALUE) {
						SendEntQuery(curBaseId, curControlId, curObjId);
					}
					break;
				case UI_HANDLE_MSG_ENTITY_CONTROL:
					SendEntControl(curBaseId, curControlId, curObjId, curEntity_type, curEntityNum, curEntityIdArr[0], msg.arg1, curEntityIdArr[1], msg.arg2);

					break;
			}
		}
	};

	void btnEnable(boolean enable) {
		Button btnSetServer = (Button) findViewById(R.id.buttonServerSet);
		Button btnServiceStart = (Button) findViewById(R.id.buttonServiceStart);
		if (enable) {
			btnSetServer.setClickable(true);
			btnSetServer.setEnabled(true);

			btnServiceStart.setClickable(true);
			btnServiceStart.setEnabled(true);
		} else {
			btnSetServer.setClickable(false);
			btnSetServer.setEnabled(false);

			btnServiceStart.setClickable(false);
			btnServiceStart.setEnabled(false);
		}
	}

	private void doRxCmd(Bundle data) {
		int len = data.getInt(NetManager.RX_LENGHT);
		byte[] dataArr = data.getByteArray(NetManager.RX_DATA);
		if (!packetform.isValidPktForm(dataArr, len)) {
			Log.i(TAG, "isValidPktForm error");
			return;
		}

		PackObj obj = packetform.getParcingPkt(dataArr, len);
		Log.i(TAG, "detail cmd:" + obj.cmdDetail);
		switch (obj.cmdDetail) {
			case PackObj.CMD_DETAIL_LOGIN_FAIL_RES:
				Toast.makeText(this, "Login fail !!!", Toast.LENGTH_LONG);
				NetMgr.stopThread();
				btnEnable(true);
				break;

			case PackObj.CMD_DETAIL_LOGIN_SUCCESS_RES:
				if (obj.login_id != loginID) {
					Log.e(TAG, "Login Id 가 틀림- Tx id:" + loginID + " Rx id:" + obj.login_id);
					NetMgr.stopThread();
					return;
				}
				NetStatus.setText("로그인 됨");
				logined = true;
				SendBaseIdQuery();
				break;
			case PackObj.CMD_DETAIL_BASE_ID_RES:
				displayBaseId(obj);
				break;
			case PackObj.CMD_DETAIL_CONT_ID_RES:
				displayControlId(obj);
				break;
			case PackObj.CMD_DETAIL_OBJ_ID_RES:
				displayObjId(obj);
				break;
			case PackObj.CMD_DETAIL_OBJ_ENT_RES:
				displayEntity(obj);
				break;
		}
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		Log.d(TAG, "OnDestroy");
		if (connectingActionDoneFlag) {
			NetMgr.stopThread();
		}
		super.onDestroy();
	}

	@Override
	protected void onRestart() {
		// TODO Auto-generated method stub
		super.onRestart();
		Log.d(TAG, "onRestart");
		if (connectingActionDoneFlag) {
			startQuerySensorTimer();
		}
	}

	@Override
	protected void onStop() {
		Log.d(TAG, "onStop");
		// TODO Auto-generated method stub
		if (connectingActionDoneFlag) {
			stopQuerySensorTimer();
		}
		super.onStop();
		// ATTENTION: This was auto-generated to implement the App Indexing API.
		// See https://g.co/AppIndexing/AndroidStudio for more information.
/*
		Action viewAction = Action.newAction(
				Action.TYPE_VIEW, // TODO: choose an action type.
				"SensorQuery Page", // TODO: Define a title for the content shown.
				// TODO: If you have web page content that matches this app activity's content,
				// make sure this auto-generated web page URL is correct.
				// Otherwise, set the URL to null.
				Uri.parse("http://host/path"),
				// TODO: Make sure this auto-generated app deep link URI is correct.
				Uri.parse("android-app://com.example.senorquery/http/host/path")
		);
*/
//		AppIndex.AppIndexApi.end(client, viewAction);

		// ATTENTION: This was auto-generated to implement the App Indexing API.
		// See https://g.co/AppIndexing/AndroidStudio for more information.
//		client.disconnect();
	}

	private void doNetStatus(int status) {
		switch (status) {
			case NetManager.NET_NONE:
				NetStatus.setText("네트워크 상태 모름");
				break;
			case NetManager.NET_DISCONNECT:
				NetStatus.setText("연결 해제");
				break;
			case NetManager.NET_CONNECTING:
				NetStatus.setText("연결 중 ...");
				break;
			case NetManager.NET_CONNECTED:
				if (!logined) {
					NetStatus.setText("연결 후 로그인 중 ...");
					Log.i(TAG, "sendLoginCmd start");
					SendLoginCmd();
					testUpdateFlag = 2;
					testStep = 0; // login
				}
				break;
		}
	}

//////////////////////////////////////////////////////////////////////
// Command  Send funtions
/////////////////////////////////////////////////////////////////////

	public int SendLoginCmd() {
		byte[] packet;
		packet = packetform.makeLoginPkt(loginID, loginPwd);
		return NetMgr.SendData(packet, packet.length);
	}

	public int SendBaseIdQuery() {
		byte[] packet;
		packet = packetform.makeQueryPkt(0, 0, 0, loginID);// base id query
		return NetMgr.SendData(packet, packet.length);
	}

	public int SendControlIDQuery(int baseId) {
		byte[] packet;
		packet = packetform.makeQueryPkt(baseId, 0, 0, loginID);
		return NetMgr.SendData(packet, packet.length);
	}

	public int SendObjIdQuery(int baseId, int controlId) {
		byte[] packet;
		packet = packetform.makeQueryPkt(baseId, controlId, 0, loginID);
		return NetMgr.SendData(packet, packet.length);
	}

	public int SendEntQuery(int baseId, int controlId, int objId) {
		byte[] packet;
		packet = packetform.makeQueryPkt(baseId, controlId, objId, loginID);
		return NetMgr.SendData(packet, packet.length);
	}

	public int SendEntControl(int baseId, int controlId, int objId, int obj_type, int ent_num, int entId1, int entvalue1, int entId2, int entvalue2) {
		byte[] packet;
		packet = packetform.makeActuatorControlPkt(baseId, controlId, objId, obj_type, ent_num, entId1, entvalue1, entId2, entvalue2);
		return NetMgr.SendData(packet, packet.length);
	}

	public int UpdateDataCmd(int baseid, int controlid, int objid) {
		byte[] packet;

		packet = packetform.makeQueryPkt(baseid, controlid, objid, loginID);
		return NetMgr.SendData(packet, packet.length);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_sensor_query, menu);
		return true;
	}

	@Override
	public void onStart() {
		super.onStart();
		// ATTENTION: This was auto-generated to implement the App Indexing API.
		// See https://g.co/AppIndexing/AndroidStudio for more information.
//		client.connect();

		// ATTENTION: This was auto-generated to implement the App Indexing API.
		// See https://g.co/AppIndexing/AndroidStudio for more information.
/*
		Action viewAction = Action.newAction(
				Action.TYPE_VIEW, // TODO: choose an action type.
				"SensorQuery Page", // TODO: Define a title for the content shown.
				// TODO: If you have web page content that matches this app activity's content,
				// make sure this auto-generated web page URL is correct.
				// Otherwise, set the URL to null.
				Uri.parse("http://host/path"),
				// TODO: Make sure this auto-generated app deep link URI is correct.
				Uri.parse("android-app://com.example.senorquery/http/host/path")
		);
		AppIndex.AppIndexApi.start(client, viewAction);
*/
	}

}

